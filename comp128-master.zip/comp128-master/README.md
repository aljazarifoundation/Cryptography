# Java COMP128 algorithm 
Java implementation of the GSM COMP128 algorithm used in A3/A8 functions.
It implements the version 1, 2 and 3 of the algorithm.

See also: https://en.wikipedia.org/wiki/COMP128